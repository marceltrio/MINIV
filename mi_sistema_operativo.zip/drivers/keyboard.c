#include <stdint.h>

uint8_t inb(uint16_t port);
void outb(uint16_t port, uint8_t value);

// Manejo de teclado
char read_key() {
    uint8_t scancode = inb(0x60);
    if (scancode & 0x80) {
        return 0;  // Tecla liberada
    }
    return scancode_to_char(scancode);
}

char scancode_to_char(uint8_t scancode) {
    const char keymap[128] = {
        0, 27, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '', '	',
        'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '
', 0, 'a', 's',
        'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', ''', '`', 0, '\', 'z', 'x', 'c', 'v',
        'b', 'n', 'm', ',', '.', '/', 0, '*', 0, ' ', 0, 0, 0, 0, 0, 0, 0, 0,
    };
    return keymap[scancode];
}
