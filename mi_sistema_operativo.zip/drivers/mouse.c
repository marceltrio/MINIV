#include <stdint.h>

uint8_t inb(uint16_t port);
void outb(uint16_t port, uint8_t value);

// Inicializa el mouse
void init_mouse() {
    outb(0x64, 0xA8); // Habilita el mouse
    outb(0x64, 0x20); // Configura el controlador
}

// Lee datos del mouse
uint8_t read_mouse() {
    return inb(0x60); // Devuelve datos del mouse
}
