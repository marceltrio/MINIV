#include <stdint.h>

// Llama a una interrupción
void int10h(uint16_t ax, uint16_t bx, uint16_t cx, uint16_t dx) {
    __asm__ volatile ("int $0x10" : : "a"(ax), "b"(bx), "c"(cx), "d"(dx));
}

// Cambia al modo gráfico VESA 1024x768
void set_graphics_mode() {
    uint16_t mode = 0x118;
    int10h(0x4F02, mode, 0, 0);
}

// Dibuja un píxel en modo VESA
void put_pixel_vesa(int x, int y, uint32_t color) {
    uint32_t *framebuffer = (uint32_t *)0xE0000000;
    framebuffer[y * 1024 + x] = color;
}
