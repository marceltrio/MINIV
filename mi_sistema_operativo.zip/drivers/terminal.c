#include "vesa.c"

#define TERMINAL_WIDTH 80
#define TERMINAL_HEIGHT 25
#define CHAR_WIDTH 8
#define CHAR_HEIGHT 16

int cursor_x = 0;
int cursor_y = 0;

void terminal_initialize() {
    cursor_x = 0;
    cursor_y = 0;
    clear_screen();  // Implementar en VESA
}

void terminal_putchar(char c) {
    if (c == '\n') {
        cursor_x = 0;
        cursor_y++;
    } else {
        draw_char(cursor_x * CHAR_WIDTH, cursor_y * CHAR_HEIGHT, c, 0xFFFFFF);
        cursor_x++;
    }

    if (cursor_x >= TERMINAL_WIDTH) {
        cursor_x = 0;
        cursor_y++;
    }
    if (cursor_y >= TERMINAL_HEIGHT) {
        scroll_terminal();  // Implementar desplazamiento
    }
}

void terminal_write(const char *str) {
    while (*str) {
        terminal_putchar(*str++);
    }
}
