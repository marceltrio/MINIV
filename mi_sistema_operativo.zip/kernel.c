#include "drivers/keyboard.c"
#include "drivers/mouse.c"
#include "drivers/vesa.c"
#include "drivers/terminal.c"

void kernel_main() {
    set_graphics_mode();  // Cambia al modo gráfico
    init_keyboard();      // Inicializa el teclado
    init_mouse();         // Inicializa el mouse

    terminal_initialize();  // Configura la terminal
    terminal_write("Bienvenido a mi sistema operativo!");

    while (1) {
        // Captura y muestra entrada del teclado
        char key = read_key();
        if (key) {
            terminal_putchar(key);
        }
    }
}
